<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\ComponentUpdate;
use App\Http\Requests\ComponentStore;
use App\Model\Component;
use Carbon\Carbon;

class ComponentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('referensi.component.index');
    }

    public function getData(Request $request)
    {
        $code_group = $request->code_group;
        $data = Component::when($code_group, function($data) use ($code_group){
            if ($code_group != 'all') {
                $data->where('code_group',$code_group);
            }
        })->get();
        if (substr(\Route::getFacadeRoot()->current()->uri(), 0, 3) == 'api') {
            return successResponse("List component.", $data);
        }
        return datatables()->of($data)
        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Edit"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'  <button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Delete"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ComponentStore $request)
    {
        $data = new Component;
        $data->com_cd = $request->code;
        $data->code_nm = $request->name;
        $data->code_group = $request->group;
        $data->code_value = $request->value;
        $data->note = $request->note;
        $data->note_2 = $request->note_2;
        $data->created_by = auth()->user()->id;
        $data->save();
        return response()->json([
            'success'=> 'Data created successfully.',
            'data'=> $data,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ComponentUpdate $request, $id)
    {
        $data = Component::findOrFail($id);
        $data->code_nm = $request->name;
        $data->code_group = $request->group;
        $data->code_value = $request->value;
        $data->note = $request->note;
        $data->note_2 = $request->note_2;
        $data->updated_by = auth()->user()->id;
        $data->save();
        return response()->json([
            'success'=> 'Data updated successfully.',
            'edit'=> 1,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Component::findOrFail($id)->delete();
        return response()->json(['status' => 'success', 'data'=>'success delete data']);
    }
}
