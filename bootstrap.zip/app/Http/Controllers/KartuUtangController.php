<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Supplier;
use App\Model\Transaksi;
use App\Model\TransaksiPembayaran;

class KartuUtangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
        return view('transaksi.kartu-utang.index');
    }

    public function getData(Request $request)
    {
        $data = Transaksi::with('supplier','transaksi_detail.stok_produk_gudang.gudang','transaksi_detail.stok_produk_gudang.stok_produk','transaksi_detail.stok_produk_gudang.stok_produk.barang','transaksi_detail.stok_produk_gudang.stok_produk.merek','transaksi_detail.stok_produk_gudang.stok_produk.kategori.kategori')
        ->whereHas('supplier')
        ->groupBy('supplier_id')
        ->selectRaw('supplier_id, sum(total_pembayaran_netto) as total_pembayaran_netto, sum(dibayar) as dibayar, sum(kurang_bayar) as kurang_bayar')
        ->get();
        return datatables()->of($data)
        ->addColumn('dibayar_formated', function($row){
            if ($row->dibayar == 0) {
                return '<span class="text-danger font-weight-black font-size-lg">'.rupiah($row->dibayar).'</span>';
            } else {
                if ($row->dibayar == $row->total_pembayaran_netto) {
                    return '<span class="text-success font-weight-black font-size-lg">'.rupiah($row->dibayar).'</span>';
                } else {
                    return '<span class="text-warning font-weight-black font-size-lg">'.rupiah($row->dibayar).'</span>';
                }
            }
        })
        ->addColumn('kurang_bayar_formated', function($row){
            if ($row->dibayar == 0) {
                return '<span class="text-danger font-weight-black font-size-lg">'.rupiah($row->kurang_bayar).'</span>';
            } else {
                if ($row->dibayar == $row->total_pembayaran_netto) {
                    return '<span class="text-success font-weight-black font-size-lg">'.rupiah($row->kurang_bayar).'</span>';
                } else {
                    return '<span class="text-warning font-weight-black font-size-lg">'.rupiah($row->kurang_bayar).'</span>';
                }
            }
        })
        ->addColumn('total_pembayaran_netto_formated', function($row){
            return '<span class="text-default font-weight-black font-size-lg">'.rupiah($row->total_pembayaran_netto).'</span>';
        })
        ->addColumn('supplier_formated', function($row){
            return '<a href="#">
                        <span class="text-default font-weight-semibold"><samp>'.$row->supplier->kode.'</samp></span>
                        <br>
                        <span class="text-default font-weight-bold font-size-lg">'
                        .$row->supplier->nama.
                        '</span>
                        <br>
                        <span class="text-default font-weight-semibold">'.$row->supplier->nomor_telepon.'</span>
                    </a>';
        })
        ->addColumn('action', function($row){
            $btn = '<a href="'.route('kartu-utang.show',$row->supplier_id).'" id="btn-detail" class="btn bg-violet btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Lihat Detail Pembayaran"><i class="icon-history mr-2"></i> Detail</a>';
            $btn = $btn.'<a href="'.route('kartu-utang.showHistorical',$row->supplier_id).'" id="btn-historical" class="btn bg-indigo btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Lihat Histori Pembayaran"><i class="icon-history mr-2"></i> Historikal</a>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action','supplier_formated','dibayar_formated','kurang_bayar_formated','total_pembayaran_netto_formated'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Supplier::find($id);
        $trans = Transaksi::where('supplier_id',$id)
        ->groupBy('supplier_id')
        ->selectRaw('supplier_id, sum(total_pembayaran_netto) as total_pembayaran_netto, sum(dibayar) as dibayar, sum(kurang_bayar) as kurang_bayar')
        ->first();
        return view('transaksi.kartu-utang.detail', compact('data','trans'));
    }

    public function getDataDetail(Request $request)
    {
        $id = $request->id;

        $trans = Transaksi::with('supplier')
        ->whereHas('supplier')
        ->where('supplier_id', $id)
        ->get();
        $pemb = TransaksiPembayaran::whereHas('transaksi', function($q) use ($id){
            return $q->where('supplier_id',$id);
        })->get();
        $data = [];
        foreach ($trans as $key => $value) {
            $data['trans_'.$value->id]['supplier_id'] = $id;
            $data['trans_'.$value->id]['transaksi_id'] = $value->id;
            $data['trans_'.$value->id]['pembayaran_id'] = null;
            $data['trans_'.$value->id]['tanggal_pembayaran'] = $value->tanggal_transaksi;
            $data['trans_'.$value->id]['total_bayar'] = $value->total_pembayaran_netto;
            $data['trans_'.$value->id]['created_at'] = $value->created_at;
            $data['trans_'.$value->id]['supplier'] = $value->supplier;
            $data['trans_'.$value->id]['tipe'] = 'Transaksi';
        }
        foreach ($pemb as $key => $value) {
            $data['pemb_'.$value->id]['supplier_id'] = $id;
            $data['pemb_'.$value->id]['transaksi_id'] = $value->transaksi_id;
            $data['pemb_'.$value->id]['pembayaran_id'] = $value->id;
            $data['pemb_'.$value->id]['tanggal_pembayaran'] = $value->tanggal_pembayaran;
            $data['pemb_'.$value->id]['total_bayar'] = $value->total_pembayaran;
            $data['pemb_'.$value->id]['created_at'] = $value->created_at;
            $data['pemb_'.$value->id]['supplier'] = $value->transaksi->supplier;
            $data['pemb_'.$value->id]['tipe'] = 'Pembayaran';
        }

        $tanggal_pembayaran = array();
        foreach ($data as $key => $row)
        {
            $tanggal_pembayaran[$key] = $row['tanggal_pembayaran'];
        }
        array_multisort($tanggal_pembayaran, SORT_ASC, $data);
        $total = 0;
        foreach ($data as $key => $value) {
            if ($value['tipe'] == 'Transaksi') {
                $total = $total + $value['total_bayar'];
            } else {
                $total = $total - $value['total_bayar'];
            }
            $data[$key]['total_kum'] = $total;
        }
        return datatables()->of($data)
        ->addColumn('nama_pembayaran', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-default font-weight-black font-size-lg">'.$row['tipe'].''.$row['transaksi_id'].'</span>';
            } else {
                return '<span class="text-default font-weight-black font-size-lg">'.$row['tipe'].' Transaksi'.$row['transaksi_id'].'</span>';
            }
        })
        ->addColumn('tanggal_pembayaran_formated', function($row){
            $tanggal = '<span class="badge bg-blue mt-1">'.\Carbon\Carbon::createFromDate($row['tanggal_pembayaran'])->translatedFormat('d F Y, H:i').'</span>';
            return $tanggal;
        })
        ->addColumn('total_bayar_formated', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-success font-weight-black font-size-lg"> + '.rupiah($row['total_bayar']).'</span>';
            } else {
                return '<span class="text-warning font-weight-black font-size-lg"> - '.rupiah($row['total_bayar']).'</span>';
            }
        })
        ->addColumn('debit_formated', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-success font-weight-black font-size-lg">+ '.rupiah($row['total_bayar']).'</span>';
            } else {
                return null;
            }
        })
        ->addColumn('kredit_formated', function($row){
            if ($row['tipe'] == 'Pembayaran') {
                return '<span class="text-warning font-weight-black font-size-lg">- '.rupiah($row['total_bayar']).'</span>';
            } else {
            }
        })
        ->addColumn('total_kum_formated', function($row){
            if ($row['total_kum'] == 0) {
                return '<span class="text-default font-weight-black font-size-lg">'.rupiah($row['total_kum']).'</span>';
            } elseif ($row['total_kum'] > 0) {
                return '<span class="text-success font-weight-black font-size-lg"> + '.rupiah($row['total_kum']).'</span>';
            } else {
                return '<span class="text-warning font-weight-black font-size-lg"> - '.rupiah($row['total_kum']).'</span>';
            }
        })
        ->addIndexColumn()
        ->rawColumns(['nama_pembayaran','tanggal_pembayaran_formated','total_bayar_formated','total_kum_formated','debit_formated','kredit_formated'])
        ->make(true);
    }

    public function showHistorical($id)
    {
        $data = Supplier::find($id);
        $trans = Transaksi::where('supplier_id',$id)
        ->groupBy('supplier_id')
        ->selectRaw('supplier_id, sum(total_pembayaran_netto) as total_pembayaran_netto, sum(dibayar) as dibayar, sum(kurang_bayar) as kurang_bayar')
        ->first();
        return view('transaksi.kartu-utang.historical', compact('data','trans'));
    }

    public function getDataDetailHistorical(Request $request)
    {
        $id = $request->id;

        $trans = Transaksi::with('supplier')
        ->whereHas('supplier')
        ->where('supplier_id', $id)
        ->get();
        $pemb = TransaksiPembayaran::whereHas('transaksi', function($q) use ($id){
            return $q->where('supplier_id',$id);
        })->get();
        $data = [];
        foreach ($trans as $key => $value) {
            $data['trans_'.$value->id]['supplier_id'] = $id;
            $data['trans_'.$value->id]['transaksi_id'] = $value->id;
            $data['trans_'.$value->id]['pembayaran_id'] = null;
            $data['trans_'.$value->id]['tanggal_pembayaran_trans'] = $value->tanggal_transaksi;
            $data['trans_'.$value->id]['tanggal_pembayaran'] = $value->tanggal_transaksi;
            $data['trans_'.$value->id]['total_bayar'] = $value->total_pembayaran_netto;
            $data['trans_'.$value->id]['created_at'] = $value->created_at;
            $data['trans_'.$value->id]['supplier'] = $value->supplier;
            $data['trans_'.$value->id]['tipe'] = 'Transaksi';
        }
        foreach ($pemb as $key => $value) {
            $data['pemb_'.$value->id]['supplier_id'] = $id;
            $data['pemb_'.$value->id]['transaksi_id'] = $value->transaksi_id;
            $data['pemb_'.$value->id]['pembayaran_id'] = $value->id;
            $data['pemb_'.$value->id]['tanggal_pembayaran_trans'] = $value->transaksi->tanggal_transaksi;
            $data['pemb_'.$value->id]['tanggal_pembayaran'] = $value->tanggal_pembayaran;
            $data['pemb_'.$value->id]['total_bayar'] = $value->total_pembayaran;
            $data['pemb_'.$value->id]['created_at'] = $value->created_at;
            $data['pemb_'.$value->id]['supplier'] = $value->transaksi->supplier;
            $data['pemb_'.$value->id]['tipe'] = 'Pembayaran';
        }

        $tanggal_pembayaran_trans = array();
        $tanggal_pembayaran = array();
        foreach ($data as $key => $row)
        {
            $tanggal_pembayaran_trans[$key] = $row['tanggal_pembayaran_trans'];
            $tanggal_pembayaran[$key] = $row['tanggal_pembayaran'];
        }
        array_multisort($tanggal_pembayaran_trans, SORT_ASC, $tanggal_pembayaran, SORT_ASC, $data);

        $total = 0;
        $old_transaksi_id = null;
        foreach ($data as $key => $value) {
            if ($old_transaksi_id != $value['transaksi_id']) {
                $total = 0;
                $data[$key]['tanggal_pembayaran_trans_formated'] = $value['tanggal_pembayaran_trans'];
            } else {
                $data[$key]['tanggal_pembayaran_trans_formated'] = '';
            }
            if ($value['tipe'] == 'Transaksi') {
                $total = $total + $value['total_bayar'];
            } else {
                $total = $total - $value['total_bayar'];
            }
            $data[$key]['total_kum'] = $total;
            $old_transaksi_id = $value['transaksi_id'];
        }
        return datatables()->of($data)
        ->addColumn('nama_pembayaran', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-default font-weight-bold font-size-lg">'.$row['tipe'].''.$row['transaksi_id'].'</span>';
            } else {
                return '<span class="text-default font-weight-bold font-size-lg">'.$row['tipe'].' Transaksi'.$row['transaksi_id'].'</span>';
            }
        })
        ->addColumn('tanggal_pembayaran_formated', function($row){
            $tanggal = '<span class="badge bg-blue mt-1">'.\Carbon\Carbon::createFromDate($row['tanggal_pembayaran'])->translatedFormat('d F Y, H:i').'</span>';
            return $tanggal;
        })
        ->addColumn('tanggal_pembayaran_trans_formated_2', function($row){
            if ($row['tanggal_pembayaran_trans_formated'] != '') {
                $tanggal = '<span class="text-default font-weight-black"><samp>Transaksi '.$row['transaksi_id'].'</samp></span>
                            <br>
                            <span class="badge bg-blue mt-1">'.\Carbon\Carbon::createFromDate($row['tanggal_pembayaran_trans_formated'])->translatedFormat('d F Y, H:i').'</span>';
            } else {
                $tanggal = '';
            }
            return $tanggal;
        })
        ->addColumn('total_bayar_formated', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-success font-weight-black font-size-lg"> + '.rupiah($row['total_bayar']).'</span>';
            } else {
                return '<span class="text-warning font-weight-black font-size-lg"> - '.rupiah($row['total_bayar']).'</span>';
            }
        })
        ->addColumn('debit_formated', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-success font-weight-black font-size-lg">+ '.rupiah($row['total_bayar']).'</span>';
            } else {
                return null;
            }
        })
        ->addColumn('kredit_formated', function($row){
            if ($row['tipe'] == 'Pembayaran') {
                return '<span class="text-warning font-weight-black font-size-lg">- '.rupiah($row['total_bayar']).'</span>';
            } else {
            }
        })
        ->addColumn('total_kum_formated', function($row){
            if ($row['total_kum'] == 0) {
                return '<span class="text-default font-weight-black font-size-lg">'.rupiah($row['total_kum']).'</span>';
            } elseif ($row['total_kum'] > 0) {
                return '<span class="text-success font-weight-black font-size-lg"> + '.rupiah($row['total_kum']).'</span>';
            } else {
                return '<span class="text-warning font-weight-black font-size-lg"> - '.rupiah($row['total_kum']).'</span>';
            }
        })
        ->addIndexColumn()
        ->rawColumns(['nama_pembayaran','tanggal_pembayaran_formated','tanggal_pembayaran_trans_formated_2','total_bayar_formated','total_kum_formated','debit_formated','kredit_formated'])
        ->make(true);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
