<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\TransaksiDetailOutUpdate;
use App\Http\Requests\TransaksiDetailOutStore;
use App\Model\Transaksi;
use App\Model\TransaksiDetail;
use App\Model\StokProdukGudang;
use Carbon\Carbon;
use Auth;
use DB;

class TransaksiDetailOutController extends Controller
{
    public function getData(Request $request)
    {
        $transaksi_id = $request->transaksi_id;
        $data = TransaksiDetail::with('stok_produk_gudang.gudang','stok_produk_gudang.stok_produk','stok_produk_gudang.stok_produk.barang','stok_produk_gudang.stok_produk.merek','stok_produk_gudang.stok_produk.kategori.kategori')
        ->where(function ($q) use ($transaksi_id){
            if ($transaksi_id) {
                return $q->where('transaksi_id', $transaksi_id)
                ->where('created_by', auth()->user()->id);
            } else {
                return $q->whereNull('transaksi_id')
                ->where('created_by', auth()->user()->id);
            }
        })
        ->where('tipe','Stok Keluar')
        ->get();

        return datatables()->of($data)
        ->addColumn('total_netto_formated', function($row){
            return 'Rp '.number_format($row->total_netto ,0,".",".").',-';
        })
        ->addColumn('harga_netto_formated', function($row){
            return 'Rp '.number_format($row->harga_netto ,0,".",".").',-';
        })
        ->addColumn('form_potongan', function($row){
            return '<input type="text" placeholder="" value="'.$row->potongan.'" class="form-control form_potongan" name="potongan" id="potongan">
                    ';
        })
        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit-detail" class="btn btn-sm btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'  <a id="btn-delete-detail" class="delete-modal btn btn-sm btn-sm btn-danger btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></a>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action', 'total_netto_formated','harga_netto_formated','form_potongan'])
        ->make(true);
    }

    public function index()
    {
        // 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TransaksiDetailOutStore $request)
    {
        DB::beginTransaction();
        foreach ($request->stok_keluar as $key => $value) {
            if (!empty($value) || $value == '0') {
                $spg = StokProdukGudang::where([
                    ['stok_produk_id',$request->produk],
                    ['gudang_id',$request->gudang[$key]]
                ])->first();
                if (!empty($spg)) {
    
                } else {
                    $spg = new StokProdukGudang;
                    $spg->stok_produk_id         = $request->produk;
                    $spg->gudang_id              = $request->gudang[$key];
                    $spg->jumlah_stok_awal       = 0;
                    $spg->jumlah_stok_sekarang   = 0;
                    $spg->created_by = auth()->user()->id;
                    $spg->save();
                }
                $detTrans = new TransaksiDetail;
                $detTrans->transaksi_id = $request->transaksi_id;
                $detTrans->stok_produk_gudang_id = $spg->id;
                $detTrans->harga        = $request->harga_jual;
                $detTrans->harga_netto  = $request->harga_jual;
                $detTrans->kuantitas    = $value;
                $detTrans->total        = $request->harga_jual * $value;
                $detTrans->total_netto  = $request->harga_jual * $value;
                $detTrans->tipe         = 'Stok Keluar';
                $detTrans->created_by  = auth()->user()->id;
                $detTrans->save();
            }
        }
        DB::commit();
        return successResponse("Berhasil menambah data.", $detTrans);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TransaksiDetailOutUpdate $request, $id)
    {
        DB::beginTransaction();
        $spg = StokProdukGudang::where([
            ['stok_produk_id',$request->produk],
            ['gudang_id',$request->gudang]
        ])->first();

        $detTrans = TransaksiDetail::findOrFail($id);
        $detTrans->stok_produk_gudang_id = $spg->id;
        $detTrans->harga        = $request->harga_jual;
        $detTrans->harga_netto  = $request->harga_jual;
        $detTrans->kuantitas    = $request->stok_keluar;
        $detTrans->total        = $request->harga_jual * $request->stok_keluar;
        $detTrans->total_netto  = $request->harga_jual * $request->stok_keluar;
        $detTrans->updated_by  = auth()->user()->id;
        $detTrans->save();
        DB::commit();
        return successResponse("Data berhasil diubah.", $detTrans);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = TransaksiDetail::findOrFail($id);
        TransaksiDetail::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.", $data);
    }

    public function getTotal(Request $request)
    {
        
        $data = TransaksiDetail::where(function ($q) use ($request){
            if ($request->trans_id) {
                return $q->where('transaksi_id', $request->trans_id)
                ->where('created_by', auth()->user()->id);
            } else {
                return $q->whereNull('transaksi_id')
                ->where('created_by', auth()->user()->id);
            }
        })->where('tipe', 'Stok Keluar')
        ->sum('total_netto');
        $message = null;
        if ($request->trans_id) {
            $transaksi = Transaksi::find($request->trans_id);
            if ($transaksi->transaksi_pembayaran->count() > 1) {
                $message = 'ada pembayaran lebih dari 1';
            }
        } else {
            $transaksi = null;
        }
        $data2  = $data;
        $data   = 'Rp '.number_format($data ,0,".",".").',-';
        return response()->json([
            'status' => 'success',
            'error' => false,
            'message' => $message,
            'transaksi' => $transaksi,
            'data' => $data,
            'data2' => $data2,
        ]);
    }

    public function potongan(Request $request)
    {
        $data = TransaksiDetail::find($request->id);
        $data->potongan = $request->potongan;
        $data->total_netto = $data->total - $request->potongan;
        $data->save();
        return response()->json([
            'status' => 'success',
            'error' => false,
            'data' => $data
        ]);
    }
}
