<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\StokProdukGudang;
use App\Model\Transaksi;
use App\Model\TransaksiDetail;
use App\Model\Gudang;
use DB;
use Carbon\Carbon;

class StokOpnameController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [];
        $data['gudang'] = Gudang::first();
        return view('transaksi.stok-opname.index', compact('data'));
    }

    public function getData(Request $request)
    {
        $data = Transaksi::with('transaksi_detail.stok_produk_gudang.gudang','transaksi_detail.stok_produk_gudang.stok_produk','transaksi_detail.stok_produk_gudang.stok_produk.barang','transaksi_detail.stok_produk_gudang.stok_produk.merek','transaksi_detail.stok_produk_gudang.stok_produk.kategori.kategori')
        ->whereDoesntHave('customer')
        ->whereDoesntHave('supplier')
        ->get();

        return datatables()->of($data)
        ->addColumn('tanggal_transaksi_formated', function($row){
            $tanggal = '<span class="badge bg-blue mt-1">'.Carbon::createFromDate($row->tanggal_transaksi)->translatedFormat('d F Y, H:i').'</span>';
            $a = [];
            foreach ($row->transaksi_detail as $key => $value) {
                $a[$value->stok_produk_gudang->gudang_id] = '<span class="badge badge-mark border-blue mr-1"></span><span class="mr-2">'.$value->stok_produk_gudang->gudang->nama.'</span>';
            }
            $gudang = implode( '', $a);
            return $gudang.'<br>'.$tanggal;
        })
        ->addColumn('waktu_penyesuaian', function($row){
            return Carbon::createFromDate($row->tanggal_transaksi)->format('Y-m-d H:i');
        })
        ->addColumn('action', function($row){
            $btn = '';
            $btn = $btn.'<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'<button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action','tanggal_transaksi_formated','waktu_penyesuaian'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function getDataCreate(Request $request)
    {
        $data = StokProdukGudang::where('gudang_id',$request->filter_gudang_id)
        ->with('gudang','stok_produk.barang','stok_produk')
        ->get()->keyBy('id')->toArray();
        if ($request->transaksi_id) {
            $transDetail = TransaksiDetail::where('transaksi_id',$request->transaksi_id)
            ->whereHas('transaksi', function ($q) use ($request){
                $q->where('tanggal_transaksi',$request->filter_waktu_penyesuaian);
            })
            ->get()->keyBy('stok_produk_gudang_id')->toArray();
            $arrData = [];
            foreach ($data as $key => $value) {
                $arrData[$key] = $value;
                if (isset($transDetail[$key])) {
                    $arrData[$key]['kuantitas'] = $transDetail[$key]['kuantitas'];
                    $arrData[$key]['jumlah_stok_sekarang'] = $arrData[$key]['jumlah_stok_sekarang'] - $transDetail[$key]['kuantitas'];
                } else {
                    $arrData[$key]['kuantitas'] = null;
                }
            }
        } else {
            $transDetail = TransaksiDetail::whereHas('transaksi', function ($q) use ($request){
                $q->where('tanggal_transaksi',Carbon::parse($request->filter_waktu_penyesuaian)->format('Y-m-d H:i'));
            })
            ->get()->keyBy('stok_produk_gudang_id')->toArray();
            if ( count($transDetail) > 0) {
                $arrData = [];
                foreach ($data as $key => $value) {
                    $arrData[$key] = $value;
                    if (isset($transDetail[$key])) {
                        $arrData[$key]['kuantitas'] = $transDetail[$key]['kuantitas'];
                        $arrData[$key]['jumlah_stok_sekarang'] = $arrData[$key]['jumlah_stok_sekarang'] - $transDetail[$key]['kuantitas'];
                    } else {
                        $arrData[$key]['kuantitas'] = null;
                    }
                }
            } else {
                foreach ($data as $key => $value) {
                    $arrData[$key] = $value;
                    $arrData[$key]['kuantitas'] = null;
                }
            }
        }
        return datatables()->of($arrData)
        ->addColumn('nama_barang_formated', function($row){
            return '<span class="font-weight-black">'.$row['stok_produk']['nama'].'</span>';
        })
        ->addColumn('jumlah_sekarang', function($row){
            return '<span class="font-weight-black">'.$row['jumlah_stok_sekarang'].'</span>';
        })
        ->addColumn('form_penyesuaian', function($row){
            if ($row['kuantitas'] != null) {
                $feedback = '<i class="icon-checkmark text-success mt-0 mb-0" id=""></i>';
            } else {
                $feedback = '<i class="icon-database-edit2 text-default mt-0 mb-0" id=""></i>';
            }
            return '
                <div class="form-group form-group-feedback form-group-feedback-left mt-0 mb-0">
                    <input id="penyesuaian_'.$row['id'].'" type="number" class="form-control form_penyesuaian" name="penyesuaian" value="'.$row['kuantitas'].'" placeholder="Jumlah penyesuaian">
                    <div class="form-control-feedback mt-0 mb-0 feedback_'.$row['id'].'" id="feedback_'.$row['id'].'">'.
                    $feedback
                    .'</div>
                </div>';
        })
        ->addColumn('form_hasil_penyesuaian', function($row){
            if ($row['kuantitas'] != null) {
                $hasilPenyesuaian = $row['jumlah_stok_sekarang'] + $row['kuantitas'];
                $feedback = '<i class="icon-checkmark text-success mt-0 mb-0" id=""></i>';
            } else {
                $hasilPenyesuaian = null;
                $feedback = '<i class="icon-database-menu text-default mt-0 mb-0" id=""></i>';
            }
            return '
                <div class="form-group form-group-feedback form-group-feedback-left mt-0 mb-0">
                    <input id="hasil_penyesuaian_'.$row['id'].'" type="number" class="form-control form_hasil_penyesuaian" name="hasil_penyesuaian" value="'.($hasilPenyesuaian).'" placeholder="Hasil penyesuaian">
                    <div class="form-control-feedback mt-0 mb-0 feedback_'.$row['id'].'" id="feedback_'.$row['id'].'">'.
                    $feedback
                    .'</div>
                </div>';
            return '<input type="text" placeholder="" value="" placeholder="Hasil penyesuaian" class="form-control form_hasil_penyesuaian" name="hasil_penyesuaian" id="hasil_penyesuaian_'.$row['id'].'">';
        })
        ->addIndexColumn()
        ->rawColumns(['form_penyesuaian','nama_barang_formated','jumlah_sekarang','form_hasil_penyesuaian'])
        ->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        DB::beginTransaction();
        if ($request->transaksi_id) {
            $data = TransaksiDetail::where([
                ['stok_produk_gudang_id',$request->stok_produk_gudang_id],
                ['tipe','Stok Opname'],
                ['transaksi_id',$request->transaksi_id],
            ])->whereHas('transaksi', function($q) use ($request){
                $q->where('tanggal_transaksi',$request->waktu_penyesuaian);
            })
            ->first();
            if ($data) {
                $data->updated_by   = auth()->user()->id;
                $data->kuantitas    = $request->penyesuaian;
            } else {
                $data = new TransaksiDetail;
                $data->tipe                 = 'Stok Opname';
                $data->transaksi_id         = $request->transaksi_id;
                $data->created_by           = auth()->user()->id;
                $data->stok_produk_gudang_id= $request->stok_produk_gudang_id;
                $data->kuantitas            = $request->penyesuaian;
            }
            
        } else {
            $data = TransaksiDetail::where([
                ['stok_produk_gudang_id',$request->stok_produk_gudang_id],
                ['tipe','Stok Opname'],
            ])->whereNull('transaksi_id')->first();
            if ($data) {
                $data->updated_by   = auth()->user()->id;
                $data->kuantitas    = $request->penyesuaian;
            } else {
                $data = new TransaksiDetail;
                $data->tipe                 = 'Stok Opname';
                $data->created_by           = auth()->user()->id;
                $data->stok_produk_gudang_id= $request->stok_produk_gudang_id;
                $data->kuantitas            = $request->penyesuaian;
            }
        }
        $data->save();
        if ($request->penyesuaian == '0' || empty($request->penyesuaian) || $request->penyesuaian == '') {
            $data->delete();
        }

        if (empty($data->transaksi_id)) {
            $trans = Transaksi::where([
                ['created_by',auth()->user()->id],
                ['tanggal_transaksi',$request->waktu_penyesuaian]
            ])->first();
            if (empty($trans)) {
                $trans = new Transaksi();
                $trans->created_by = auth()->user()->id;
            }
        } else {
            $trans = $data->transaksi;
            $trans->updated_by = auth()->user()->id;
        }
        $trans->tanggal_transaksi = $request->waktu_penyesuaian;
        $trans->save();

        $data->transaksi_id = $trans->id;
        $data->save();
        DB::commit();
        return response()->json([
            'status' => 'success',
            'error' => false,
            'data' => $data,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        $transaksi = Transaksi::findOrFail($id);
        foreach ($transaksi->transaksi_detail as $key => $value) {
            $value->delete();
        }
        foreach ($transaksi->transaksi_pembayaran as $key => $value) {
            $value->delete();
        }
        $transaksi->delete();
        DB::commit();
        return successResponse("Data berhasil dihapus!.");
    }
}
