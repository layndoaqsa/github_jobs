<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\SupplierUpdate;
use App\Http\Requests\SupplierStore;
use App\Model\Supplier;
use Carbon\Carbon;
use Auth;

class SupplierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('referensi.supplier.index');
    }

    public function getData(Request $request)
    {
        $data = Supplier::all();
        return datatables()->of($data)
        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'  <button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SupplierStore $request)
    {
        $data = new Supplier;
        $data->kode = $request->kode;
        $data->nama = $request->nama;
        $data->nomor_telepon = $request->nomor_telepon;
        $data->alamat = $request->alamat;
        $data->created_by = auth()->user()->id;
        $data->save();
        return successResponse("Berhasil menambah data.", $data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(SupplierUpdate $request, $id)
    {
        $data = Supplier::findOrFail($id);
        $data->kode = $request->kode;
        $data->nama = $request->nama;
        $data->nomor_telepon = $request->nomor_telepon;
        $data->alamat = $request->alamat;
        $data->updated_by = auth()->user()->id;
        $data->save();
        return successResponse("Data berhasil diubah.", $data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Supplier::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.");
    }
}
