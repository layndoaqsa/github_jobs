<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\StokProdukUpdate;
use App\Http\Requests\StokProdukStore;
use App\Model\StokProduk;
use App\Model\StokProdukKategori;
use App\Model\StokProdukGudang;
use App\Model\TransaksiDetail;
use Carbon\Carbon;
use Auth;
use DB;

class StokProdukController extends Controller
{
    public function index()
    {
        return view('transaksi.stok-produk.index');
    }

    public function getData(Request $request)
    {
        $data = StokProduk::with('barang','merek','kategori.kategori','gudang.gudang')->get();
        return datatables()->of($data)
        ->addColumn('barang_merek', function($row){
            if ($row->merek) {
                $merek = '<span class="d-block font-size-sm text-muted font-weight-normal mb-0 mt-0">'.$row->merek->nama.'</span>';
                $barang = '<span class="d-block font-size-sm text-muted font-weight-normal mb-0 mt-0">'.$row->barang->nama.'</span>';
                return $barang.''.$merek;
            } else {
                $barang = '<span class="d-block font-size-sm text-muted font-weight-normal mb-0 mt-0">'.$row->barang->nama.'</span>';
                return $barang;
            }
        })
        ->addColumn('all_kategori', function($row){
            $a = [];
            if ($row->kategori) {
                foreach ($row->kategori as $key => $value) {
                    if ($value->kategori) {
                        $a[] = $value->kategori->kategori;
                    } else {
                        $a[] = '';
                    }
                }
                return '<span class="d-block font-size-sm text-muted font-weight-normal mb-0 mt-0">'.implode( ',<br>', $a).'</span>';
            } else {
                return null;
            }
        })
        ->addColumn('gudang_stok', function($row){
            $a = [];
            foreach ($row->gudang as $key => $value) {
                $a[] = '<a href="'.route("stok-produk.show",[$row->id, "gudang_id"=>$value->gudang_id]).'" data-toggle="tooltip" data-placement="top" title="Riwayat Stok '.$value->gudang->nama.'" type="button" class="btn btn-sm btn-outline text-indigo-600 bg-indigo-600 border-indigo-600"><span class="font-weight-bold font-size-lg">'.$value->jumlah_stok_sekarang.'</span><br>'.$value->gudang->nama.'</a>';
            }
            return '<div class="btn-group">'.implode( '<br>', $a).'</div>';
        })
        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'<button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addColumn('harga_jual_formated', function($row){
            $harga = '<h6 class="mb-0 font-weight-bold">'.rupiah($row->harga_jual).'</h6>';
            return $harga;
        })
        ->addColumn('nama_formated', function($row){
            return '<span class="text-default font-weight-bold font-size-lg">'.$row->nama.'</span>
            <br>
            <span class="text-default font-weight-semibold"><samp>'.$row->kode.'</samp></span>';
        })
        ->addColumn('kode_formated', function($row){
            return '<span class="text-default font-weight-semibold"><samp>'.$row->kode.'</samp></span>';
        })
        ->addIndexColumn()
        ->rawColumns(['action', 'all_kategori', 'gudang_stok','barang_merek','nama_formated','kode_formated','harga_jual_formated'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StokProdukStore $request)
    {
        DB::beginTransaction();
        $stok_produk = new StokProduk;
        $stok_produk->barang_id            = $request->jenis_barang;
        $stok_produk->merek_id             = $request->merek;
        $stok_produk->nama                 = $request->nama;
        $stok_produk->kode                 = $request->kode;
        $stok_produk->deskripsi            = $request->deskripsi;
        $stok_produk->harga_jual           = $request->harga_jual;
        $stok_produk->harga_beli           = $request->harga_beli;
        $stok_produk->created_by           = auth()->user()->id;
        $stok_produk->save();

        foreach ($request->kategori as $key => $value) {
            if (!empty($value)) {
                $kategori = new StokProdukKategori;
                $kategori->stok_produk_id       = $stok_produk->id;
                $kategori->kategori_id          = $value;
                $kategori->created_by           = auth()->user()->id;
                $kategori->save();
            }
        }

        foreach ($request->gudang as $key => $value) {
            if (!empty($value)) {
                $gudang = new StokProdukGudang;
                $gudang->stok_produk_id         = $stok_produk->id;
                $gudang->gudang_id              = $value;
                $gudang->jumlah_stok_sekarang   = $gudang->jumlah_stok_sekarang - $gudang->jumlah_stok_awal + $request->jumlah_stok_awal[$key];
                $gudang->jumlah_stok_awal       = $request->jumlah_stok_awal[$key] ? : 0;
                $gudang->created_by = auth()->user()->id;
                $gudang->save();
            }
        }
        DB::commit();
        return successResponse("Berhasil menambah data.", $stok_produk);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $data = StokProduk::find($id);
        return view('transaksi.stok-produk.detail', compact('data','request'));
    }

    public function getDataDetail(Request $request)
    {
        $data = TransaksiDetail::leftJoin('transaksi AS a','a.id','transaksi_detail.transaksi_id')
        ->leftJoin('stok_produk_gudang AS b','b.id','transaksi_detail.stok_produk_gudang_id')
        ->where(function($q) use ($request) {
            if ($request->filter_gudang_id) {
                $q->where('b.stok_produk_id',$request->id)
                ->where('b.gudang_id',$request->filter_gudang_id);
            } else {
                $q->where('b.stok_produk_id',$request->id);
            }
        })
        ->with('stok_produk_gudang.gudang','transaksi.supplier','transaksi.customer')
        ->orderBy('a.tanggal_transaksi', 'ASC')
        ->select('a.tanggal_transaksi', 'transaksi_detail.*')->get();
        $total_stok = 0;
        foreach ($data as $key => $value) {
            if ($value->transaksi->supplier) {
                $total_stok = $total_stok + $value->kuantitas;
            } else {
                $total_stok = $total_stok - $value->kuantitas;
            }
            $value->total_stok = $total_stok;
        }
        
        return datatables()->of($data)
        ->addColumn('supplier_customer', function($row){
            if ($row->transaksi->supplier) {
                return '<a href="#">
                        <span class="text-default font-weight-semibold"><samp>'.$row->transaksi->supplier->kode.'</samp></span>
                        <br>
                        <span class="text-default font-weight-bold font-size-lg">'
                        .$row->transaksi->supplier->nama.
                        '</span>
                        <br>
                        <span class="text-default font-weight-semibold">'.$row->transaksi->supplier->nomor_telepon.'</span>
                        </a>';
            } else {
                return '<a href="#">
                        <span class="text-default font-weight-semibold"><samp>'.$row->transaksi->customer->kode.'</samp></span>
                        <br>
                        <span class="text-default font-weight-bold font-size-lg">'
                        .$row->transaksi->customer->nama.
                        '</span>
                        <br>
                        <span class="text-default font-weight-semibold">'.$row->transaksi->customer->nomor_telepon.'</span>
                        </a>';
            }
        })
        ->addColumn('kuantitas_formated', function($row){
            switch ($row->tipe) {
              case 'Stok Masuk':
                return '<h5 class="text-success font-weight-black">+ '.$row->kuantitas.'</h5>';
                break;
              case 'Stok Keluar':
              return '<h5 class="text-warning font-weight-black">- '.$row->kuantitas.'</h5>';
                $amount = $row['record_amount'];
                break;
              default:
                break;
            }
        })
        ->addColumn('jumlah', function($row){
            return $row->total_stok;
        })
        ->addColumn('jumlah_formated', function($row){
            return '<h5 class="text-grey-800 font-weight-black">'.$row->total_stok.'</h5>';
        })
        ->addColumn('tanggal_transaksi_formated', function($row){
            $tanggal = '<span class="badge bg-blue">'.\Carbon\Carbon::createFromDate($row->tanggal_transaksi)->translatedFormat('d F Y, H:i').'</span>';
            $gudang = '<div class="text-muted mb-1"><span class="badge badge-mark border-blue mr-1"></span>'.$row->stok_produk_gudang->gudang->nama.'</div>';
            return $gudang.''.$tanggal;
        })
        ->addColumn('action', function($row){
            $btn = '<a href="'.route("stok-produk.show",$row->id).'" class="btn bg-indigo btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Riwayat"><i class="icon-stack"></i></a>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action','supplier_customer','tanggal_transaksi_formated','kuantitas_formated','jumlah_formated'])
        ->make(true);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StokProdukUpdate $request, $id)
    {
        DB::beginTransaction();
        $stok_produk = StokProduk::findOrFail($id);
        $stok_produk->barang_id            = $request->jenis_barang;
        $stok_produk->merek_id             = $request->merek;
        $stok_produk->nama                 = $request->nama;
        $stok_produk->kode                 = $request->kode;
        $stok_produk->deskripsi            = $request->deskripsi;
        $stok_produk->harga_jual           = $request->harga_jual;
        $stok_produk->harga_beli           = $request->harga_beli;
        $stok_produk->updated_by           = auth()->user()->id;
        $stok_produk->save();

        foreach (StokProdukKategori::where('stok_produk_id',$id)->get() as $key => $value) {
            $value->delete();
        }
        if ($request->kategori) {
            foreach ($request->kategori as $key => $value) {
                $kategori = new StokProdukKategori;
                $kategori->stok_produk_id        = $stok_produk->id;
                $kategori->kategori_id          = $value;
                $kategori->created_by           = auth()->user()->id;
                $kategori->updated_by           = auth()->user()->id;
                $kategori->save();
            }
        }

        foreach ($request->gudang as $key => $value) {
            $gudang = StokProdukGudang::where([['gudang_id',$value], ['stok_produk_id',$id]])->first();
            if (!empty($gudang)) {
                $gudang->jumlah_stok_sekarang   = $gudang->jumlah_stok_sekarang - $gudang->jumlah_stok_awal + $request->jumlah_stok_awal[$key];
            } else {
                $gudang = new StokProdukGudang;
                $gudang->stok_produk_id = $id;
                $gudang->gudang_id      = $value;
                $gudang->created_by     = auth()->user()->id;
                $gudang->jumlah_stok_sekarang   = $request->jumlah_stok_awal[$key] ? : 0;
            }
            $gudang->jumlah_stok_awal   = $request->jumlah_stok_awal[$key] ? : 0;
            $gudang->updated_by         = auth()->user()->id;
            $gudang->save();
        }
        DB::commit();
        return successResponse("Data berhasil diubah.", $stok_produk);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        StokProduk::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.");
    }

    public function infoStok($id,$gudang_id)
    {
        $data = StokProdukGudang::where([
            ['stok_produk_id', $id],
            ['gudang_id', $gudang_id],
        ])->with('gudang')->first();
        return response()->json([
            'status'  => 'success',
            'data' => $data
        ]);
    }
}
