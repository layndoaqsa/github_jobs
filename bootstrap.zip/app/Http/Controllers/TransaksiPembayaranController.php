<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Transaksi;
use App\Model\TransaksiPembayaran;
use App\Http\Requests\TransaksiPembayaranStore;
use App\Http\Requests\TransaksiPembayaranUpdate;
use DB;

class TransaksiPembayaranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function getData(Request $request)
    {
        $transaksi_id = $request->transaksi_id;
        $trans = Transaksi::with('supplier','customer')
        ->where('id', $transaksi_id)
        ->get();
        $pemb = TransaksiPembayaran::with('transaksi')
        ->where('transaksi_id',$transaksi_id)
        ->get();
        $data = [];
        foreach ($trans as $key => $value) {
            $data['trans_'.$value->id]['transaksi_id'] = $value->id;
            $data['trans_'.$value->id]['pembayaran_id'] = null;
            $data['trans_'.$value->id]['tanggal_pembayaran'] = $value->tanggal_transaksi;
            $data['trans_'.$value->id]['total_bayar'] = $value->total_pembayaran_netto;
            $data['trans_'.$value->id]['created_at'] = $value->created_at;
            $data['trans_'.$value->id]['supplier'] = $value->supplier;
            $data['trans_'.$value->id]['customer'] = $value->customer;
            $data['trans_'.$value->id]['tipe'] = 'Transaksi';
        }
        foreach ($pemb as $key => $value) {
            $data['pemb_'.$value->id]['transaksi_id'] = $value->transaksi_id;
            $data['pemb_'.$value->id]['pembayaran_id'] = $value->id;
            $data['pemb_'.$value->id]['tanggal_pembayaran'] = $value->tanggal_pembayaran;
            $data['pemb_'.$value->id]['total_bayar'] = $value->total_pembayaran;
            $data['pemb_'.$value->id]['created_at'] = $value->created_at;
            $data['pemb_'.$value->id]['supplier'] = $value->transaksi->supplier;
            $data['pemb_'.$value->id]['customer'] = $value->transaksi->customer;
            $data['pemb_'.$value->id]['tipe'] = 'Pembayaran';
        }

        $tanggal_pembayaran = array();
        foreach ($data as $key => $row)
        {
            $tanggal_pembayaran[$key] = $row['tanggal_pembayaran'];
        }
        array_multisort($tanggal_pembayaran, SORT_ASC, $data);
        $total = 0;
        foreach ($data as $key => $value) {
            if ($value['tipe'] == 'Transaksi') {
                $total = $total + $value['total_bayar'];
            } else {
                $total = $total - $value['total_bayar'];
            }
            $data[$key]['total_kum'] = $total;
        }
        return datatables()->of($data)
        ->addColumn('nama_pembayaran', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-default font-weight-black font-size-lg">'.$row['tipe'].''.$row['transaksi_id'].'</span>';
            } else {
                return '<span class="text-default font-weight-black font-size-lg">'.$row['tipe'].' Transaksi'.$row['transaksi_id'].'</span>';
            }
        })
        ->addColumn('tanggal_pembayaran_formated', function($row){
            $tanggal = '<span class="badge bg-blue mt-1">'.\Carbon\Carbon::createFromDate($row['tanggal_pembayaran'])->translatedFormat('d F Y, H:i').'</span>';
            return $tanggal;
        })
        ->addColumn('total_bayar_formated', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-success font-weight-black font-size-lg"> + '.rupiah($row['total_bayar']).'</span>';
            } else {
                return '<span class="text-warning font-weight-black font-size-lg"> - '.rupiah($row['total_bayar']).'</span>';
            }
        })
        ->addColumn('debit_formated', function($row){
            if ($row['tipe'] == 'Transaksi') {
                return '<span class="text-success font-weight-black font-size-lg">+ '.rupiah($row['total_bayar']).'</span>';
            } else {
                return null;
            }
        })
        ->addColumn('kredit_formated', function($row){
            if ($row['tipe'] == 'Pembayaran') {
                return '<span class="text-warning font-weight-black font-size-lg">- '.rupiah($row['total_bayar']).'</span>';
            } else {
            }
        })
        ->addColumn('total_kum_formated', function($row){
            if ($row['total_kum'] == 0) {
                return '<span class="text-default font-weight-black font-size-lg">'.rupiah($row['total_kum']).'</span>';
            } elseif ($row['total_kum'] > 0) {
                return '<span class="text-success font-weight-black font-size-lg"> + '.rupiah($row['total_kum']).'</span>';
            } else {
                return '<span class="text-warning font-weight-black font-size-lg"> - '.rupiah($row['total_kum']).'</span>';
            }
        })
        ->addColumn('action', function($row){
            if ($row['tipe'] == 'Pembayaran') {
                $btn = '<a id="btn-edit-pembayaran" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
                $btn = $btn.'  <a id="btn-delete-pembayaran" class="delete-modal btn btn-sm btn-danger btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></a>';
                return '<div class="btn-group">'.$btn.'</div>';
            } else {
                return null;
            }
        })
        ->addIndexColumn()
        ->rawColumns(['action','nama_pembayaran','tanggal_pembayaran_formated','total_bayar_formated','total_kum_formated','debit_formated','kredit_formated'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TransaksiPembayaranStore $request)
    {
        DB::beginTransaction();
        $data                       = new TransaksiPembayaran;
        $data->transaksi_id         = $request->pembayaran_transaksi_id;
        $data->tanggal_pembayaran   = $request->tanggal_waktu_pembayaran;
        $data->total_pembayaran     = $request->total_pembayaran;
        $data->created_by           = auth()->user()->id;
        $data->save();
        DB::commit();
        return successResponse("Berhasil menambah data.", $data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TransaksiPembayaranUpdate $request, $id)
    {
        DB::beginTransaction();
        $data = TransaksiPembayaran::findOrFail($id);
        $data->tanggal_pembayaran   = $request->tanggal_waktu_pembayaran;
        $data->total_pembayaran     = $request->total_pembayaran;
        $data->updated_by           = auth()->user()->id;
        $data->save();
        DB::commit();
        return successResponse("Data berhasil diubah.", $data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = TransaksiPembayaran::findOrFail($id);
        TransaksiPembayaran::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.", $data);
    }
}
