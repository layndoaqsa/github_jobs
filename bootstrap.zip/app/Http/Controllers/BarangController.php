<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\BarangUpdate;
use App\Http\Requests\BarangStore;
use App\Model\Barang;
use Carbon\Carbon;
use Auth;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('referensi.barang.index');
    }

    public function getData(Request $request)
    {
        $data = Barang::all();
        return datatables()->of($data)
        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'  <button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BarangStore $request)
    {
        $data = new Barang;
        $data->kode = $request->kode;
        $data->nama = $request->nama;
        $data->deskripsi = $request->deskripsi;
        $data->created_by = auth()->user()->id;
        $data->save();
        return successResponse("Berhasil menambah data.", $data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BarangUpdate $request, $id)
    {
        $data = Barang::findOrFail($id);
        $data->kode = $request->kode;
        $data->nama = $request->nama;
        $data->deskripsi = $request->deskripsi;
        $data->updated_by = auth()->user()->id;
        $data->save();
        return successResponse("Data berhasil diubah.", $data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Barang::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.");
    }

    public function renderCode(Request $request)
    {
        $model = $request->model;
        $cd = $request->cd;
        $cd = 'B';
        if (!empty($request->product_id)) {
            $product = RefProduct::find($request->product_id);
            if ($product->product_category_id == $request->category_id) {
                $code = $product->code;
            } else {
                $product = RefProduct::where('product_category_id', $request->category_id)->orderBy('code', 'DESC')->first();
                if(!empty($product)){
                    $lastNumber = intval(substr($product->code, 4))+1;
                    $code = $cd.'-'.str_pad($lastNumber, 3,'0',STR_PAD_LEFT);
                } else {
                    $code = $cd."-001";
                }
            }
        } else {
            $data = Barang::orderBy('kode', 'DESC')->first();
            if(!empty($data)){
                $lastNumber = intval(substr($data->kode, -3))+1;
                $kode = $cd.'-'.str_pad($lastNumber, 3,'0',STR_PAD_LEFT);
            } else {
                $kode = $cd."-001";
            }
        }


        return response()->json([
            'status'  => 'success',
            'message' => $kode
        ]);
    }
}
