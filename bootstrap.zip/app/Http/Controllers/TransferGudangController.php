<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\TransferGudang;
use App\Http\Requests\TransferGudangUpdate;
use App\Http\Requests\TransferGudangStore;


class TransferGudangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('transaksi.transfer-gudang.index');
    }

    public function getData(Request $request)
    {
        $data = TransferGudang::with('dari_gudang','ke_gudang','stok_produk')->get();
        return datatables()->of($data)
        ->addColumn('tanggal_transfer_formated', function($row){
            $tanggal = '<span class="badge bg-blue mt-1">'.\Carbon\Carbon::createFromDate($row->tanggal_transfer)->translatedFormat('d F Y, H:i').'</span>';
            return $tanggal;
        })

        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'  <button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action','tanggal_transfer_formated'])
        ->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TransferGudangStore $request)
    {
        $data = new TransferGudang;
        $data->tanggal_transfer = $request->waktu_transfer_gudang;
        $data->stok_produk_id = $request->stok_produk;
        $data->dari_gudang_id = $request->gudang_asal;
        $data->ke_gudang_id = $request->gudang_tujuan;
        $data->kuantitas = $request->kuantitas;
        $data->created_by = auth()->user()->id;
        $data->save();
        return successResponse("Berhasil menambah data.", $data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TransferGudangUpdate $request, $id)
    {
        $data = TransferGudang::findOrFail($id);
        $data->tanggal_transfer = $request->waktu_transfer_gudang;
        $data->stok_produk_id = $request->stok_produk;
        $data->dari_gudang_id = $request->gudang_asal;
        $data->ke_gudang_id = $request->gudang_tujuan;
        $data->kuantitas = $request->kuantitas;
        $data->updated_by = auth()->user()->id;
        $data->save();
        return successResponse("Data berhasil diubah.", $data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        TransferGudang::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.");
    }
}
