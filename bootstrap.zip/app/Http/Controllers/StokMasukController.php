<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\StokMasukUpdate;
use App\Http\Requests\StokMasukStore;
use App\Model\Transaksi;
use App\Model\TransaksiDetail;
use App\Model\StokProdukKategori;
use App\Model\StokProdukGudang;
use App\Model\TransaksiPembayaran;
use Carbon\Carbon;
use Auth;
use DB;

class StokMasukController extends Controller
{
    public function index()
    {
        return view('transaksi.stok-masuk.index');
    }

    public function getData(Request $request)
    {
        $data = Transaksi::with('supplier','transaksi_detail.stok_produk_gudang.gudang','transaksi_detail.stok_produk_gudang.stok_produk','transaksi_detail.stok_produk_gudang.stok_produk.barang','transaksi_detail.stok_produk_gudang.stok_produk.merek','transaksi_detail.stok_produk_gudang.stok_produk.kategori.kategori')
        ->whereHas('supplier')->get();

        return datatables()->of($data)
        ->addColumn('tipe_nama', function($row){
            switch ($row->tipe) {
                case 'TIPE_PEMBAYARAN_KELUAR_01':
                    $tipe = '<span class="badge badge-success">'.comName($row->tipe).'</span>';
                    break;
                case 'TIPE_PEMBAYARAN_KELUAR_02':
                    $tipe = '<span class="badge badge-danger">'.comName($row->tipe).'</span>';
                    break;
                case 'TIPE_PEMBAYARAN_KELUAR_03':
                    $tipe = '<span class="badge badge-warning">'.comName($row->tipe).'</span>';
                    break;
                default:
                    $tipe = '<span class="badge badge-primary">'.comName($row->tipe).'</span>';
                    break;
                    break;
            }
            return $tipe;
        })
        ->addColumn('dibayar_formated', function($row){
            if ($row->dibayar == 0) {
                return '<span class="text-danger font-weight-black font-size-lg">'.rupiah($row->dibayar).'</span>';
            } else {
                if ($row->dibayar == $row->total_pembayaran_netto) {
                    return '<span class="text-success font-weight-black font-size-lg">'.rupiah($row->dibayar).'</span>';
                } else {
                    return '<span class="text-warning font-weight-black font-size-lg">'.rupiah($row->dibayar).'</span>';
                }
            }
        })
        ->addColumn('kurang_bayar_formated', function($row){
            if ($row->dibayar == 0) {
                return '<span class="text-danger font-weight-black font-size-lg">'.rupiah($row->kurang_bayar).'</span>';
            } else {
                if ($row->dibayar == $row->total_pembayaran_netto) {
                    return '<span class="text-success font-weight-black font-size-lg">'.rupiah($row->kurang_bayar).'</span>';
                } else {
                    return '<span class="text-warning font-weight-black font-size-lg">'.rupiah($row->kurang_bayar).'</span>';
                }
            }
        })
        ->addColumn('potongan_persen_formated', function($row){
            return $row->potongan_persen.'%';
        })
        ->addColumn('total_netto_formated', function($row){
            return '<span class="text-default font-weight-black font-size-lg">'.rupiah($row->total_pembayaran_netto).'</span>';
        })
        ->addColumn('supplier_formated', function($row){
            return '<a href="#">
                        <span class="text-default font-weight-semibold"><samp>'.$row->supplier->kode.'</samp></span>
                        <br>
                        <span class="text-default font-weight-bold font-size-lg">'
                        .$row->supplier->nama.
                        '</span>
                        <br>
                        <span class="text-default font-weight-semibold">'.$row->supplier->nomor_telepon.'</span>
                    </a>';
        })
        ->addColumn('tanggal_transaksi_formated', function($row){
            $tanggal = '<span class="badge bg-blue mt-1">'.\Carbon\Carbon::createFromDate($row->tanggal_transaksi)->translatedFormat('d F Y, H:i').'</span>';
            $a = [];
            foreach ($row->transaksi_detail as $key => $value) {
                $a[$value->stok_produk_gudang->gudang_id] = '<span class="badge badge-mark border-blue mr-1"></span><span class="mr-2">'.$value->stok_produk_gudang->gudang->nama.'</span>';
            }
            $gudang = implode( '', $a);
            return $gudang.'<br>'.$tanggal;
        })
        ->addColumn('action', function($row){
            $btn = '<a id="btn-pembayaran" class="btn btn-sm bg-indigo btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Pembayaran"><i class="icon-cash3"></i></a>';
            $btn = $btn.'<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'<button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action', 'tipe_nama','supplier_formated','tanggal_transaksi_formated','dibayar_formated','kurang_bayar_formated','total_netto_formated'])
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('transaksi.stok-masuk.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StokMasukStore $request)
    {
        DB::beginTransaction();
        $transaksi = new Transaksi;
        $transaksi->supplier_id         = $request->supplier;
        $transaksi->tanggal_transaksi   = $request->waktu_transaksi;
        $transaksi->tipe              = $request->tipe_pembayaran;
        $transaksi->created_by          = auth()->user()->id;
        $transaksi->save();

        $detailTransaksi = TransaksiDetail::with('stok_produk_gudang.gudang','stok_produk_gudang.stok_produk','stok_produk_gudang.stok_produk.barang','stok_produk_gudang.stok_produk.merek','stok_produk_gudang.stok_produk.kategori.kategori')
        ->where('created_by', auth()->user()->id)
        ->where('tipe', 'Stok Masuk')
        ->whereNull('transaksi_id')
        ->get();

        $total = 0;
        foreach ($detailTransaksi as $key => $value) {
            $value->transaksi_id = $transaksi->id;
            $value->save();
            $total = $total + $value->total_netto;
        }
        $transaksi->total_pembayaran_netto = $total;
        $transaksi->total_pembayaran = $total;
        $transaksi->save();
        
        switch ($transaksi->tipe) {
            case 'TIPE_PEMBAYARAN_KELUAR_01': //lunas
                $dibayar = $transaksi->total_pembayaran_netto;
                break;
            case 'TIPE_PEMBAYARAN_KELUAR_02': //hutang
                $dibayar = 0;
                break;
            case 'TIPE_PEMBAYARAN_KELUAR_03': //bertahap
                $dibayar = $request->dibayar;
                break;
            default:
                break;
        }
        if ($dibayar > 0) {
            $data = new TransaksiPembayaran;
            $data->transaksi_id         = $transaksi->id;
            $data->total_pembayaran     = $dibayar;
            $data->tanggal_pembayaran   = \Carbon\Carbon::createFromDate($transaksi->tanggal_transaksi)->addMinutes(1);
            $data->created_by      = auth()->user()->id;
            $data->save();
        }
        DB::commit();
        return successResponse("Berhasil menambah data.", $transaksi);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StokMasukUpdate $request, $id)
    {
        DB::beginTransaction();
        $transaksi = Transaksi::findOrFail($id);
        $transaksi->supplier_id         = $request->supplier;
        $transaksi->tanggal_transaksi   = $request->waktu_transaksi;
        $transaksi->tipe                = $request->tipe_pembayaran;
        $transaksi->updated_by          = auth()->user()->id;
        $transaksi->save();
        switch ($transaksi->tipe) {
            case 'TIPE_PEMBAYARAN_KELUAR_01': //lunas
                $dibayar = $transaksi->total_pembayaran_netto;
                break;
            case 'TIPE_PEMBAYARAN_KELUAR_02': //hutang
                $dibayar = 0;
                break;
            case 'TIPE_PEMBAYARAN_KELUAR_03': //bertahap
                $dibayar = $request->dibayar;
                break;
            default:
                break;
        }
        switch ($transaksi->transaksi_pembayaran->count()) {
            case '0':
                if ($dibayar > 0) {
                    $data = new TransaksiPembayaran;
                    $data->transaksi_id         = $transaksi->id;
                    $data->total_pembayaran     = $dibayar;
                    $data->tanggal_pembayaran   = \Carbon\Carbon::createFromDate($transaksi->tanggal_transaksi)->addMinutes(1);
                    $data->created_by           = auth()->user()->id;
                    $data->save();
                }
                break;
            case '1':
                $data = $transaksi->transaksi_pembayaran[0];
                if ($dibayar == 0) {
                    $data->delete();
                } else {
                    $data->total_pembayaran     = $dibayar;
                    $data->tanggal_pembayaran   = \Carbon\Carbon::createFromDate($transaksi->tanggal_transaksi)->addMinutes(1);
                    $data->updated_by           = auth()->user()->id;
                    $data->save();
                }
                break;
            default:
                transaksiTipe($transaksi);
                break;
        }
        DB::commit();
        return successResponse("Data berhasil diubah.", $transaksi);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        $transaksi = Transaksi::findOrFail($id);
        foreach ($transaksi->transaksi_detail as $key => $value) {
            $value->delete();
        }
        foreach ($transaksi->transaksi_pembayaran as $key => $value) {
            $value->delete();
        }
        $transaksi->delete();
        DB::commit();
        return successResponse("Data berhasil dihapus!.");
    }
}
