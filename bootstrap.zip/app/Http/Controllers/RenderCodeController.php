<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\BarangUpdate;
use App\Http\Requests\BarangStore;
use App\Model\Barang;
use App\Model\Gudang;
use App\Model\Customer;
use App\Model\Supplier;
use App\Model\StokProduk;
use Carbon\Carbon;
use Auth;

class RenderCodeController extends Controller
{
    public function barang(Request $request)
    {
        $cd = 'B';
        $data = Barang::orderBy('kode', 'DESC')->first();
        if(!empty($data)){
            $lastNumber = intval(substr($data->kode, -4))+1;
            $kode = $cd.'-'.str_pad($lastNumber, 4,'0',STR_PAD_LEFT);
        } else {
            $kode = $cd."-0001";
        }
        return response()->json([
            'status'  => 'success',
            'kode' => $kode
        ]);
    }

    public function customer(Request $request)
    {
        $cd = 'C';
        $data = Customer::orderBy('kode', 'DESC')->first();
        if(!empty($data)){
            $lastNumber = intval(substr($data->kode, -4))+1;
            $kode = $cd.'-'.str_pad($lastNumber, 4,'0',STR_PAD_LEFT);
        } else {
            $kode = $cd."-0001";
        }
        return response()->json([
            'status'  => 'success',
            'kode' => $kode
        ]);
    }

    public function supplier(Request $request)
    {
        $cd = 'S';
        $data = Supplier::orderBy('kode', 'DESC')->first();
        if(!empty($data)){
            $lastNumber = intval(substr($data->kode, -4))+1;
            $kode = $cd.'-'.str_pad($lastNumber, 4,'0',STR_PAD_LEFT);
        } else {
            $kode = $cd."-0001";
        }
        return response()->json([
            'status'  => 'success',
            'kode' => $kode
        ]);
    }

    public function gudang(Request $request)
    {
        $cd = 'G';
        $data = Gudang::orderBy('kode', 'DESC')->first();
        if(!empty($data)){
            $lastNumber = intval(substr($data->kode, -4))+1;
            $kode = $cd.'-'.str_pad($lastNumber, 4,'0',STR_PAD_LEFT);
        } else {
            $kode = $cd."-0001";
        }
        return response()->json([
            'status'  => 'success',
            'kode' => $kode
        ]);
    }

    public function stokProduk(Request $request)
    {
        $cd = $request->cd;
        $cd_count = strlen($cd);
        $data = StokProduk::where('kode', 'like', $cd.'%')->orderBy('kode', 'DESC')->first();
        if(!empty($data)){
            $lastNumber = intval(substr($data->kode, -3))+1;
            $kode = $cd.'-'.str_pad($lastNumber, 3,'0',STR_PAD_LEFT);
        } else {
            $kode = $cd."-001";
        }
        return response()->json([
            'status'  => 'success',
            'kode' => $kode
        ]);
    }
}
