<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;
use Spatie\Permission\Models\Role;
use App\Http\Requests\UserStore;
use App\Http\Requests\UserUpdate;
use App\Http\Requests\UserUpdateProfileSelf;
use App\Http\Requests\UserUpdatePasswordSelf;
use App\Imports\UserImport;
use Excel;
use Auth;
Use Alert;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::all();
        return view('user.index',compact('role'));
    }

    public function getData(Request $request)
     {
        $role = $request->filter_role;
        $data = User::whereHas("roles", function($q) use ($role) {
            if (!empty($role) && $role != 'all') {
                $q->where("name", $role);
            }
        })->get();
         return datatables()->of($data)
         ->addColumn('action', function($row){
             if ($row->id != auth()->user()->id) {
                 $btn = '<a href="'.route('user.edit',Crypt::encrypt($row->id)).'" class="btn btn-sm btn-warning btn-icon" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
                 $btn = $btn.'  <button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
                 return '<div class="btn-group">'.$btn.'</div>';
             } else {
                 return null;
             }
         })
         ->addIndexColumn()
         ->rawColumns(['action','owner_group'])
         ->make(true);
     }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $role = Role::all();
        return view('user.create', compact('role'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserStore $request)
    {
        $user = new User();
        $user->name         = $request->name;
        $user->email        = $request->email;
        $user->password     = \Hash::make($request->password);
        $user->save();
        $user->roles()->sync(1);
        return response()->json([
            'success'=> 'Berhasil menambah data.',
            'data'=> $user,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $data = User::findOrFail(Crypt::decrypt($id));
            $role = Role::all();
            return view('user.edit',compact('data','role'));
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            return abort(404);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(UserUpdate $request, $id)
    {
        $user = User::findOrFail($id);
        $user->name = $request->name;
        $user->email = $request->email;
        if ($request->password) {
            $user->password = \Hash::make($request->password);
        }
        $user->save();
        return response()->json([
            'success'=> 'Data berhasil diubah.',
            'data'=> $user,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::findOrFail($id)->delete();
        return response()->json(['status' => 'success', 'data'=>'Data berhasil dihapus']);
    }

    public function myProfile()
    {
      $data = User::findOrFail(Auth::user()->id);
      return view('user.my-profile',compact('data'));
    }

    public function updateProfile(Request $request)
    {
        $this->validate(request(),
        [
            'nama' => 'required',
            'email' => 'required|unique:users,email,'.Auth::user()->id,
            'phone_number' => 'nullable|max:16|min:11|unique:users,phone_number,'.Auth::user()->id,
        ]
        );

        $user = User::findOrFail(Auth::user()->id);

        $user->name = $request->nama;
        $user->email = $request->email;
        $user->save();
        return redirect()->route('profile.index')->with('alertSuccess','Data berhasil diubah!');
    }

    public function updateProfileApi(UserUpdateProfileSelf $request)
    {
        $user = auth()->user();
        $user->name = $request->nama;
        $user->email = $request->email;
        $user->save();
        return successResponse("Data berhasil diubah.", $user);
    }

    public function updatePassword(Request $request)
    {
        $data= User::findOrFail(Auth::user()->id);
        if(Hash::check($request->current_password,$data->password)){
          $data->password = Hash::make($request->password);
          $this->validate($request,
            [
              'current_password' => 'required',
              'password' => 'required|string|min:8|confirmed|max:191',
            ]);
          $data->save();
          return redirect()->route('profile.index')->with('alertSuccess','Password berhasil diubah!');
        }
        else{
          return redirect()->route('profile.index')->with('errorPassword','Password tidak cocok.');
        }
    }

    public function import(Request $request)
    {
        try {
            $rules = [
                'file' => 'required|mimes:xls,xlsx',
            ];
            $validator = Validator::make($request->all(), $rules);
            if ($validator->fails()) {
                return redirect()->back()->with('alertWarningNoTimer',$validator->errors()->first());
            }
            $import = Excel::import(new UserImport(), $request->file('file'));
        }
        catch (\Exception $e) {
            return redirect()->back()->with('alertWarningNoTimer',$e->getMessage());
        }
        return redirect()->back()->with('alertSuccess','Data berhasil diimport');
    }
}
