<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\KategoriUpdate;
use App\Http\Requests\KategoriStore;
use App\Model\Kategori;
use Carbon\Carbon;
use Auth;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        

        return view('referensi.kategori.index');
    }

    public function getData(Request $request)
    {
        $data = Kategori::all();
        return datatables()->of($data)
        ->addColumn('action', function($row){
            $btn = '<a id="btn-edit" class="btn btn-sm btn-warning btn-icon text-white" data-toggle="tooltip" data-placement="right" title="Ubah"><i class="icon-pencil4"></i></a>';
            $btn = $btn.'  <button id="btn-delete" class="delete-modal btn btn-sm btn-danger btn-icon" data-toggle="tooltip" data-placement="right" title="Hapus"><i class="icon-trash"></i></button>';
            return '<div class="btn-group">'.$btn.'</div>';
        })
        ->addIndexColumn()
        ->rawColumns(['action'])
        ->make(true);
    }

    public function getTree(){
        $tree = function ($elements, $parentId = null) use (&$tree) {
            $branch = array();
            $html = '';
            foreach ($elements as $element) {
                if ($element['kategori_parent'] == $parentId) {
                    $children = $tree($elements, $element['id']);
                    if ($children) {
                        $element['children'] = $children;
                    }  else {
                        $element['children'] = [];
                    }
                    $branch[] = $element;
                }
            }
            return $branch;
        };

        $data = Kategori::select('id','kategori as title','kategori_parent')->get()->toArray();
        foreach ($data as $key => $value) {
            $data[$key]['expanded'] = true;
        }
        $tree = $tree($data);
        return response()->json($tree);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(KategoriStore $request)
    {
        $data = new Kategori;
        $data->kategori_parent = $request->parent;
        $data->kategori = $request->nama_kategori;
        $data->created_by = auth()->user()->id;
        $data->save();
        return successResponse("Berhasil menambah data.", $data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(KategoriUpdate $request, $id)
    {
        $data = Kategori::findOrFail($id);
        $data->kategori_parent = $request->parent;
        $data->kategori = $request->nama_kategori;
        $data->updated_by = auth()->user()->id;
        $data->save();
        return successResponse("Data berhasil diubah.", $data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Kategori::findOrFail($id)->delete();
        return successResponse("Data berhasil dihapus!.");
    }
}
