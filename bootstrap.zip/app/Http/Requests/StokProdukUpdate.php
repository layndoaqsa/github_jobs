<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StokProdukUpdate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'jenis_barang' => 'required',
            'merek' => 'required',
            'harga_jual' => 'required|numeric',
            'harga_beli' => 'required|numeric',
            'nama' => 'required|max:255|unique:stok_produk,nama,'.$this->id,
            'kode' => 'required|max:255|unique:stok_produk,kode,'.$this->id,
            'jumlah_stok_awal' => 'required',
            'deskripsi' => 'max:255',
        ];
    }
}
