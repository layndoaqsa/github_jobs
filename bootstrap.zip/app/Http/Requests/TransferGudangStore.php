<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TransferGudangStore extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'waktu_transfer_gudang' => 'required',
            'stok_produk' => 'required',
            'gudang_asal' => 'required',
            'gudang_tujuan' => 'required',
            'kuantitas' => 'required',
        ];
    }
}
