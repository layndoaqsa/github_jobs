<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StokKeluarUpdate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $tipe_pembayaran = $this->request->get('tipe_pembayaran');
        switch ($tipe_pembayaran) {
            case 'TIPE_PEMBAYARAN_MASUK_01':
            case 'TIPE_PEMBAYARAN_MASUK_02':
                return [
                    'customer' => 'required',
                    'waktu_transaksi' => 'required',
                    'tipe_pembayaran' => 'required',
                ];
                break;
            case 'TIPE_PEMBAYARAN_MASUK_03':
                return [
                    'customer' => 'required',
                    'waktu_transaksi' => 'required',
                    'tipe_pembayaran' => 'required',
                    'dibayar' => 'required',
                ];
                break;
            default:
                return [
                    'customer' => 'required',
                    'waktu_transaksi' => 'required',
                ];
                break;
        }
    }
}
