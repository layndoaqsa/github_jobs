<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStokProduk extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stok_produk', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('barang_id')->nullable()->unsigned();
            $table->bigInteger('merek_id')->nullable()->unsigned();
            $table->string('nama')->nullable();
            $table->string('kode')->nullable();
            $table->string('deskripsi')->nullable();
            $table->integer('harga_jual')->nullable();
            $table->integer('harga_beli')->nullable();

            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
            
            $table->foreign('created_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('barang_id')->references('id')->on('barang')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('merek_id')->references('id')->on('merek')->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stok_produk');
    }
}
