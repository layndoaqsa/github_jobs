<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransferGudang extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transfer_gudang', function (Blueprint $table) {
            $table->id();
            $table->datetime('tanggal_transfer')->nullable();
            $table->bigInteger('stok_produk_id')->nullable()->unsigned();
            $table->bigInteger('dari_gudang_id')->nullable()->unsigned();
            $table->bigInteger('ke_gudang_id')->nullable()->unsigned();
            $table->integer('kuantitas')->nullable()->unsigned();
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('stok_produk_id')->references('id')->on('stok_produk')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('dari_gudang_id')->references('id')->on('gudang')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('ke_gudang_id')->references('id')->on('gudang')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transfer_gudang');
    }
}
