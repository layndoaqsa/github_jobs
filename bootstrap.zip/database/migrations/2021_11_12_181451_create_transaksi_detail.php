<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransaksiDetail extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaksi_detail', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('stok_produk_gudang_id')->nullable()->unsigned();
            $table->bigInteger('transaksi_id')->nullable()->unsigned();
            $table->integer('harga')->nullable();
            $table->integer('harga_netto')->nullable();
            $table->integer('potongan')->nullable();
            $table->integer('potongan_persen')->nullable();
            $table->integer('kuantitas')->nullable();
            $table->integer('total')->nullable();
            $table->integer('total_netto')->nullable();
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('created_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            
            $table->foreign('stok_produk_gudang_id')->references('id')->on('stok_produk_gudang')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('transaksi_id')->references('id')->on('transaksi')->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaksi_detail');
    }
}
