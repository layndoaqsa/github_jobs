<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStokProdukGudang extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stok_produk_gudang', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('stok_produk_id')->nullable()->unsigned();
            $table->bigInteger('gudang_id')->nullable()->unsigned();
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->integer('jumlah_stok_awal')->nullable();
            $table->integer('jumlah_stok_sekarang')->nullable();
            $table->timestamps();

            $table->foreign('created_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('restrict')->onUpdate('cascade');
            
            $table->foreign('stok_produk_id')->references('id')->on('stok_produk')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('gudang_id')->references('id')->on('gudang')->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stok_produk_gudang');
    }
}
