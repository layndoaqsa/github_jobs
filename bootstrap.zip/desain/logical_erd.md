@startuml
hide circle
left to right direction

entity assets {
    *id : bigint <<autoincrement>>
    --
    '--
    *asset_number           : varchar
    *asset_description      : varchar
    *location_number        : varchar
    *location_description   : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint <<default 0>>
    'updated_by  : bigint
}

entity bank_datas {
    *id : bigint <<autoincrement>>
    --
    '--
    *asset_id         : bigint <<FK>>
    *system         : varchar
    description     : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity evidences {
    *id : bigint <<autoincrement>>
    --
    *job_instruction_id : bigint <<FK>>
    *progress           : decimal
    evidence_file_path  : varchar
    actual_start        : timestamp
    actual_finish       : timestamp
    qc_check            : boolean
    qc_check            : boolean
    note_rejected       : text
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}


entity failure_reportings {
    *id : bigint <<autoincrement>>
    --
    *work_task_id: bigint <<FK>>
    *problem     : string
    *cause       : string
    *remedy      : string
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}



entity files {
    *id : bigint <<autoincrement>>
    --
    *bank_data_id   : bigint <<FK>>
    *name           : varchar
    description     : varchar
    *url            : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity job_instructions {
    *id : bigint <<autoincrement>>
    --
    *work_task_id       : bigint <<FK>>
    *number             : string <<unique>>
    *type               : enum (pre, imp, post)
    *duration           : integer
    *schedule_start     : timestamp
    *progress           : decimal
    *qc_check           : boolean
    *test_form          : boolean
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity material_wt {
    *id : bigint <<autoincrement>>
    --
    '--
    *work_task_id      : bigint <<FK>>
    *material_id       : bigint <<FK>>
    *quantity          : integer
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity materials {
    *id : bigint <<autoincrement>>
    --
    *number       : varchar <<unique>>
    *description  : varchar 
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity predesessors {
    *id : bigint <<autoincrement>>
    --
    *work_parent_id : bigint <<FK>>
    *number         : varchar <<unique>>
    *report_by      : enum('FF','FS','SS',SF) 
    *send_to        : varchar
    *description    : varchar
    *status         : varchar 
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity quick_reports {
    *id : bigint <<autoincrement>>
    --
    *job_instruction_id : bigint <<FK>>
    *predesessor        : bigint <<unique>>
    *type               : enum('FF','FS','SS',SF) 
    *day                : integer 
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity quick_report_evidences {
    *id : bigint <<autoincrement>>
    --
    *quick_report_id    : bigint <<FK>>
    *type               : varchar
    *evidence_file_path : varchar 
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity roles {
    *id : bigint <<autoincrement>>
    --
    *name : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
}

entity service_requests {
    *id : bigint <<autoincrement>>
    --
    *work_order_id  : bigint <<FK>>
    *number         : varchar
    description     : varchar
    indication      : varchar
    impact          : varchar
    risk            : varchar
    deviation       : varchar
    isolation       : varchar
    location        : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity technician_wt {
    *id : bigint <<autoincrement>>
    --
    *work_task_id   : bigint <<FK>>
    *name           : varchar
    *level          : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity tool_wt {
    *id : bigint <<autoincrement>>
    --
    '--
    *work_task_id   : bigint <<FK>>
    *tool_id        : bigint <<FK>>
    *quantity       : integer
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity tools {
    *id : bigint <<autoincrement>>
    --
    *number       : varchar <<unique>>
    *description  : varchar 
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity users {
    *id : bigint <<autoincrement>>
    --
    *role_id        : bigint <<FK>>
    *email          : varchar <<unique>>
    *username       : varchar <<unique>>
    *nid            : varchar <<unique>>
    *password       : varchar
    phone_number    : varchar
    owner_group     : varchar
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint <<default 0>>
    'updated_by  : bigint
}

entity work_orders {
    *id : bigint <<autoincrement>>
    --
    *work_parent_id : bigint <<FK>>
    *asset_id       : bigint <<FK>>
    *number         : string <<unique>>
    *type           : varchar
    *description    : text
    sched_start     : timestamp
    sched_finish    : timestamp
    actual_start    : timestamp
    actual_finish   : timestamp
    progress        : decimal
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity work_parents {
    *id : bigint <<autoincrement>>
    --
    *number         : string <<unique>>
    *name           : varchar
    *description    : text
    sched_start     : timestamp
    sched_finish    : timestamp
    actual_start    : timestamp
    actual_finish   : timestamp
    progress        : decimal
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity work_task_verifications {
    *id : bigint <<autoincrement>>
    --
    *work_task_id           : bigint <<FK>>
    permit_number           : string
    ptw_number              : string
    k3l_permit_ptw          : bigint <<FK>>
    planner                 : bigint <<FK>>
    koordinator_bidang      : bigint <<FK>>
    qc                      : bigint <<FK>>
    qc_acc                  : boolean
    start_up                : bigint <<FK>>
    start_up_acc            : boolean
    k3l                     : bigint <<FK>>
    k3l_acc                 : boolean
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}

entity work_tasks {
    *id : bigint <<autoincrement>>
    --
    *work_order_id  : bigint <<FK>>
    *number         : string <<unique>>
    *description    : varchar
    *site           : varchar
    *status         : varchar
    *priority       : varchar
    sched_start     : timestamp
    sched_finish    : timestamp
    actual_start    : timestamp
    actual_finish   : timestamp
    progress        : decimal
    owner_group     : varchar
    isolation_safety: text
    '--
    '*created_at : timestamp
    'updated_at  : timestamp
    'deleted_at  : timestamp
    '*created_by : bigint
    'updated_by  : bigint
}


roles               |o..|{  users
work_parents        |o..|{  work_orders
work_parents        |o..|{  quick_reports
quick_reports        |o..|{  quick_report_evidences
work_orders         |o..|{  assets
work_orders         |o..|{  work_tasks
work_orders         ||..o|  service_requests
work_tasks          |o..||  failure_reportings
work_tasks          |o..|{  job_instructions
work_tasks          ||..||  work_task_verifications
users               |o..||  work_task_verifications
work_tasks          |o..||  technician_wt
work_tasks          |o..||  material_wt
work_tasks          |o..||  tool_wt
tool_wt             |o..||  tools
material_wt         |o..||  materials
job_instructions    |o..|{  evidences
job_instructions    |o..|{  predesessors
bank_datas          |o..|{  files
assets              |o..|{  bank_datas

@enduml