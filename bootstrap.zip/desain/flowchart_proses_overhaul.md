@startuml
|Planner|
|Korbid|
|Planner|
start
:Status Open;
|Korbid|
:Input data planned & actual Labor;
:Status Waiting Permit;
|K3|
:Input Permit & Operation;
:Status Waiting PTW;
|PTW Officer|
:Input PTW;
:Status Ready;
|Teknisi|
repeat
    if (Progress WT 100%?) then (yes)
        ->Yes;
        break
    endif
        ->no(status In Progress);
        repeat
        :Input evidence dan progress;
        |QC|
        repeat while (diterima?) is (no(status In Progress))
        ->yes; 
|Teknisi|
repeat while (Semua job instruction selesai) is (no)
->yes; 
repeat
repeat
repeat
    :Input failure reporting;
    :Status In Waiting Approval QC;
    |QC|
    repeat while (approve?) is (no)
->yes;
    :Status Waiting Approval Startup;
    |Startup|
    repeat while (approve?) is (no)
->yes;
    :Status Waiting Approval K3L;
    |K3L|
    repeat while (approve?) is (no)
->yes;
:Status Close;
stop

@enduml