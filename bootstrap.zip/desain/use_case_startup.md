@startuml
left to right direction
skinparam linetype ortho

actor "Quality Control" as super_user
'actor "Planner" as planner
'actor "KorBid" as korbid
'actor "K3" as k3l
'actor "PTW" as ptw
'actor "Teknisi" as teknisi
'actor "QC" as qc
'actor "Start Up" as startup
'actor "PM" as pm
'actor "Review" as review
'actor "Lingkungan" as lingkungan

package "APMON-PRO"{
    ' Master
    usecase "Melihat Dashboard" as dashboard
    usecase "Melihat Bank Data" as bank_data
        usecase "Melihat Data File" as file
    usecase "Melihat Data Work Order" as work_order
    usecase "Mengelola Data Work Task" as work_task
        usecase "Mengelola Data Failure Reporting" as failure_reporting
    usecase "Melihat Data Planned and Actual Tool" as planned_tool
    usecase "Melihat Data Planned and Actual Material" as planned_material
    usecase "Melihat Data Planned and Actual Labor" as planned_labor
    usecase "Melihat Data Job Instruction" as job_instruction
        usecase "Melihat Data Evidence" as evidence
    usecase "Membuat Quick Report" as quick_report
    usecase "Mengubah Status" as update_status
}

work_task <.. failure_reporting : <<include>>
job_instruction <.. evidence : <<include>>
bank_data <.. file : <<include>>
work_task <.. update_status : <<include>>

super_user --> planned_tool
super_user --> planned_material
super_user --> planned_labor
super_user --> work_order
super_user --> work_task
super_user --> dashboard
super_user --> job_instruction
super_user --> quick_report
super_user --> evidence
super_user --> failure_reporting
super_user --> bank_data
super_user --> file
super_user --> update_status
@enduml
