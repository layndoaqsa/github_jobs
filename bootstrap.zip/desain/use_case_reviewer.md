@startuml
left to right direction
skinparam linetype ortho

actor "Reviewer" as super_user
'actor "Planner" as planner
'actor "KorBid" as korbid
'actor "K3" as k3l
'actor "PTW" as ptw
'actor "Teknisi" as teknisi
'actor "QC" as qc
'actor "Start Up" as startup
'actor "PM" as pm
'actor "Review" as review
'actor "Lingkungan" as lingkungan

package "APMON-PRO"{
    ' Master
    usecase "Melihat Dashboard" as dashboard
    usecase "Menambah Quick Report" as quick_report
}


super_user --> dashboard
super_user --> quick_report
@enduml
