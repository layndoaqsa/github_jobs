@startuml
|Planner|
start
:Masuk halaman create work parent;
|Sistem|
:Tampil form work parent;
|Planner|
repeat
    :Input data work parent;
    |Sistem|
    repeat while (valid?) is (no)
->yes;
|Database|
:Simpan data work parent;
|Sistem|
:Tampil form work order;
|Planner|
repeat
    :Input data work order;
    |Sistem|
    repeat while (valid?) is (no)
->yes;
|Database|
:Simpan data work order;
|Sistem|
:Tampil form work parent;
|Planner|
repeat
    :Input data work parent;
    |Sistem|
    repeat while (valid?) is (no)
->yes;
|Database|
:Simpan data work task;
|Sistem|
:Tampil form detail work parent;
|Planner|
repeat
    :Input data job instruction;
    :Input data planned and actual material;
    :Input data planned and actual tool;
    |Sistem|
    repeat while (valid?) is (no)
->yes;
|Database|
:Simpan data detail work task;
|Sistem|
:Tampil halaman list job card;
stop
@enduml